# niri-wsr
Automatic workspace renamer for Niri window manager
